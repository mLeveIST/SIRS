# Scenario

Collaborative applications allow groups of users to create and edit documents remotely. These documents are regularly synchronized between personal devices and the remote servers. In these applications, a user, owner of the document, can select contributors which have access to the document. Documents should not be accessed by unauthorized parties. If an attacker accesses the servers storing the documents he must not be able to view the documents and if he tries to edit any document, there must be a way to detect the illegal modifications.

A ransomware attack happens when a system is breached and the attacker encrypts the user files and asks for a ransom to provide the decryption key. If properly implemented, recovering the files without the decryption key is an intractable problem. Also, the identification of the attackers can be difficult with the use of cryptocurrencies like BitCoin.
Organizations must have backups, with version history, to allow recovery in the case of ransomware attacks.

In this topic, the solution should allow documents to be shared over a public network in a secure fashion. It should allow authenticated users to access local and remote files in a transparent way. Data confidentiality must be assured even in the case where an attacker gains physical access to the data storage devices. Illegal modification of the documents by unauthorized users must be detected. The document system should resist ransomware attacks.

## Identified Problem

The given scenario depends heavily on the reliable communication between a central server and a set of client machines, and thus suffers from the possibility of attacks to this channel, such as spoofing, replay, man-in-the-middle, and others.

Another worry to take into account is the threat of ransomware, since the main server will function as a storage for potentially shared files and documents, susceptible to malicious code. This code can propagate through the network and encrypt the files of users and servers, offering the key for decryption for a hefty amount, usually through the use of cryptocurrency such as Bitcoin.

Finally, there is also the possibility of a physical attack to the servers, where an intruder (attacker) might access the data servers and attempt to read or modify a document to which he has no permissions.

These are considered to be the three main points where security problems may arise and where security mechanisms will need to be implemented in order to guarantee a secure environment. Additionally, in this manner, not only is the risk of an attack minimized, but also the impact and damage of a successful one mitigated through the recovery of documents.

### Requirements

- Authenticity, Integrity, Confidentiality and Freshness in communications between all parties;
- Client side file encryption for storage confidentiality;
- Detection and recovery from integrity and ransomware attacks to the shared documents;

### Trust Assumptions

- We won't trust users if they don’t have the correct permissions for a specified document or whose requests don’t assure authenticity, integrity, confidentiality and freshness;
- We won’t trust anyone with physical access to file servers in terms of both read and write access;
- We will trust that the servers won’t become unavailable, due to malfunction or denial of service;
- We will trust that there will be no malicious physical access to the Logs Server;
- We will trust that there will be no malicious physical access to more than one file storing server at
once. This includes the main File Server and the Backup Servers;
